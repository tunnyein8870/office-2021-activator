Installation (require Internet)
extract 'Office201.zip'.
install-x64-basic.bat

Activation 
run office_2021_activate.bat by 'run as administrator'

